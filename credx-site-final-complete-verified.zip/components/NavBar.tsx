import Link from 'next/link';

export default function NavBar() {
  return (
    <nav className="bg-black text-white px-6 py-4 shadow-md">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold">CREDX</Link>
        <div className="space-x-6 text-sm">
          <Link href="/features">Features</Link>
          <Link href="/about">About</Link>
          <Link href="/support">Support</Link>
          <Link href="/privacy">Privacy</Link>
          <Link href="/terms">Terms</Link>
        </div>
      </div>
    </nav>
  );
}
