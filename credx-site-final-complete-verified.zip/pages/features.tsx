import NavBar from '../components/NavBar';

export default function FeaturesPage() {
  const features = [
    { title: "Unified Credit Hub", description: "Link and manage all your cards and credit lines with real-time insights.", icon: "💳" },
    { title: "Smart Bill Payments", description: "Set up one-tap auto-pay with overdraft protection and due reminders.", icon: "💡" },
    { title: "AI Fraud Detection", description: "We monitor anomalies and hidden fees to keep your money safe.", icon: "🧠" },
    { title: "Instant Credit Approval", description: "Get approved for short-term credit lines in under 2 minutes.", icon: "⚡" },
    { title: "Rewards & Cashback", description: "Earn every time you pay a bill—redeem via our in-app store.", icon: "🎁" },
    { title: "P2P Lending", description: "Borrow or lend money securely with smart matching and risk scores.", icon: "🔁" },
    { title: "Secure by Design", description: "256-bit encryption, MFA, and secure cloud infrastructure.", icon: "🔒" },
    { title: "Real Support, 24/7", description: "Talk to a bot—or a human. We’re always here for you.", icon: "💬" },
  ];

  return (
    <>
      <NavBar />
      <div className="min-h-screen bg-black text-white px-8 py-20">
        <h1 className="text-5xl font-extrabold text-center mb-16">All Features</h1>
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((f) => (
            <div key={f.title} className="bg-slate-800 rounded-2xl p-8 shadow-md hover:scale-105 transition">
              <div className="text-4xl mb-4">{f.icon}</div>
              <h2 className="text-2xl font-semibold mb-2">{f.title}</h2>
              <p className="text-slate-300 text-sm">{f.description}</p>
            </div>
          ))}
        </div>
        <div className="mt-20 text-center text-sm text-slate-400 space-y-1">
          <p>Founder & CEO: Mr. Dadi</p>
          <p>Contact: 203-589-9774</p>
          <p>Email: dnave1@unh.newhaven.edu</p>
        </div>
      </div>
    </>
  );
}
