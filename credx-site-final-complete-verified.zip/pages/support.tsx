import NavBar from '../components/NavBar';

export default function Page() {
  return (
    <>
      <NavBar />
      <div className="min-h-screen bg-slate-950 text-white px-6 py-20 flex items-center justify-center">
        <div className="max-w-3xl text-center">
          <h1 className="text-4xl font-bold mb-6">Support: Contact us anytime at support@credx.co</h1>
        </div>
      </div>
    </>
  );
}
