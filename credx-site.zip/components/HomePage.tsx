import React from "react";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center px-6">
      <div className="text-center">
        <h1 className="text-5xl font-bold mb-4">Welcome to CREDX</h1>
        <p className="text-slate-300 text-lg">
          A new way to manage credit, pay bills, and earn rewards.
        </p>
      </div>
    </div>
  );
}
